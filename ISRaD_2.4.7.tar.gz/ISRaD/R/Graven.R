#' Graven dataset for delta-delta calculation
#'
#' Data from Graven et al 2017 https://www.geosci-model-dev.net/10/4405/2017/gmd-10-4405-2017.pdf
#'
#' @format dataframe

"graven"
