
test_that("ISRaD.rep.count.frc", {
  # Errors with bad input
  expect_error(ISRaD.rep.count.frc(1))
})
