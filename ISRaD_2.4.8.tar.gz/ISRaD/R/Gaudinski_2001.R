#' Gaudinski Harvard Forest example dataset
#'
#' Data from Gaudinski, J., 2001, Belowground carbon cycling in three temperate forests of the eastern United States, University of California Irvine, Ph.D. thesis
#'
#' @format list

"Gaudinski_2001"
